package Gaurav;

public @interface Autowired {

}
