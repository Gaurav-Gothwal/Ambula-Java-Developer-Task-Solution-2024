package Gaurav;

public @interface Entity {

}
