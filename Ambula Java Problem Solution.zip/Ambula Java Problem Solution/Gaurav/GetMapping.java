package Gaurav;

public @interface GetMapping {

}
