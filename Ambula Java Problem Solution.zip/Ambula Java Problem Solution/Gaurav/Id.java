package Gaurav;

public @interface Id {

}
