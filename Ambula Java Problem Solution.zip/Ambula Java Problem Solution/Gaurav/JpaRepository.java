package Gaurav;

public interface JpaRepository<T1, T2> {

}
