package Gaurav;

public @interface PathVariable {

}
