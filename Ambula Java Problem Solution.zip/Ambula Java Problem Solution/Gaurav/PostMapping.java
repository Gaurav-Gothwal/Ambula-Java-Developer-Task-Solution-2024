package Gaurav;

public @interface PostMapping {

}
