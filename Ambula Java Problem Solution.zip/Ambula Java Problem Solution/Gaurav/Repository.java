package Gaurav;

public @interface Repository {

}
