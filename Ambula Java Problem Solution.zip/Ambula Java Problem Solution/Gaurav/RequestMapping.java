package Gaurav;

public @interface RequestMapping {

}
