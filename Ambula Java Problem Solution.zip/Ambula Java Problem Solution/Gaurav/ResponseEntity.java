package Gaurav;

public class ResponseEntity<T> {

}
