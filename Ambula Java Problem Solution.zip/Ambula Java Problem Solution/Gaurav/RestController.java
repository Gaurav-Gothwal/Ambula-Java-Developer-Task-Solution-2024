package Gaurav;

public @interface RestController {

}
