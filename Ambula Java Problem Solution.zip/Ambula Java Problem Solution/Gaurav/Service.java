package Gaurav;

public @interface Service {

}
