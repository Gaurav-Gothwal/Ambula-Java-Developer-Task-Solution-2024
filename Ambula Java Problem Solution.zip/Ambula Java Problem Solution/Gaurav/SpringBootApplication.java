package Gaurav;

public @interface SpringBootApplication {

}
